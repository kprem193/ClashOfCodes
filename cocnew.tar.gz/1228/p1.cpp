#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main()
{
srand(time(NULL));
int a;
a=rand();
a=rand();
a=(rand()*rand())%100+1;
printf("%d l",a);
return 0;
}